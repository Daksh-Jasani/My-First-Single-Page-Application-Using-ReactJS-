import React from "react";

const Post = () => {
return (
	<footer className="App-footer">
		<p>Copyright © DJ</p>
	</footer>
);
};

export default Post;