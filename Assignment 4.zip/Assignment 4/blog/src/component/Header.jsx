import React from "react";
// import { Link } from "react-router-dom";

const Post = () => {
return (
	<header className="App-header">
        <h1>DJ'S BLOG</h1>
        <div className="links">
          {/* <Link to="/Blog"> Blog </Link> */}
        </div>
      </header>
);
};

export default Post;